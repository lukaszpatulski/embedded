#include "os_threads.h"

RTX_thread::RTX_thread(os_pthread callbackFunc, osPriority priority, uint32_t instances, uint32_t stacksize, osThreadId &threadId)
{
	instance_thread.pthread   = callbackFunc;
	instance_thread.tpriority = priority;
	instance_thread.instances = instances;
	instance_thread.stacksize = stacksize;
	
	threadId = osThreadCreate( &instance_thread, NULL );
}


/* ======================= Custom classes ============================ */

void CommunicationThread::collback_function(void const *arg)
{
	
	 T_MEAS    *mptr;
 
  mptr = (T_MEAS*)osPoolAlloc(mpool);                     // Allocate memory for the message
  mptr->voltage = 22;                        // Set the message content
  mptr->current = 1;
  mptr->counter = 12;
	mptr->expander = 3;
  osMessagePut(MsgBox, (uint32_t)mptr, osWaitForever);  // Send Message
  osDelay(100);
 
  mptr = (T_MEAS*)osPoolAlloc(mpool);                     // Allocate memory for the message
  mptr->voltage = 3;                        // Prepare a 2nd message
  mptr->current = 1;
  mptr->counter = 3;
	mptr->expander = 3;
  osMessagePut(MsgBox, (uint32_t)mptr, osWaitForever);  // Send Message
  osThreadYield();                               // Cooperative multitasking
                                                 // We are done here, exit this thread
	
}