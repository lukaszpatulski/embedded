#ifndef OS_TIMER
#define OS_TIMER

#include "cmsis_os.h"

class RTX_timer
{
	private:
		
		osTimerDef_t instance_timer;
		static osTimerId id_timer;
	
	public:
		
		static void collback_function(void const *arg);
		
		RTX_timer(os_timer_type type);
	  
		bool start_timer(int delay);
		bool stop_timer(void);
	
		operator bool() const { return (id_timer != NULL); }
		bool operator!() const {return (id_timer == NULL); }
};

#endif