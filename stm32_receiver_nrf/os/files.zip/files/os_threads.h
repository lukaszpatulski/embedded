#ifndef OS_THREAD
#define OS_THREAD

#include "cmsis_os.h"

typedef struct {                                 // Message object structure
  uint8_t    voltage;                              // AD result of measured voltage
  uint8_t    current;                              // AD result of measured current
  uint8_t    counter;                              // A counter value
	uint8_t    expander;
} T_MEAS;

osPoolId  mpool;
osMessageQId  MsgBox;

class RTX_thread
{
	private:
		
		osThreadDef_t instance_thread;
	
	public:

		RTX_thread(os_pthread callbackFunc, osPriority priority, uint32_t instances, uint32_t stacksize, osThreadId &threadId);
};

/* ======================= Custom classes ============================ */

class CommunicationThread: public RTX_thread
{
	public:

		static osThreadId id_thread;

		static void collback_function(void const *arg); // Customize only callback function

		CommunicationThread(osPriority priority, uint32_t instances, uint32_t stacksize): 
		RTX_thread(collback_function, priority, instances, stacksize, id_thread) {}
			
	  operator bool() const { return (id_thread != NULL); }
		bool operator!() const {return (id_thread == NULL); }

};

#endif
