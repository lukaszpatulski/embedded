#include "os_timer.h"
   	
RTX_timer::RTX_timer(os_timer_type type)
{
	instance_timer.ptimer = collback_function;
	instance_timer.timer = reinterpret_cast<void*>(collback_function);

	id_timer = osTimerCreate(&instance_timer, type, NULL);
}

bool RTX_timer::start_timer(int delay)
{
	osStatus status = osTimerStart (id_timer, delay);
	if (status != osOK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool RTX_timer::stop_timer(void)
{
	osStatus status = osTimerStop(id_timer);
	if (status != osOK)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void RTX_timer::collback_function (void const *arg)
{
	
}